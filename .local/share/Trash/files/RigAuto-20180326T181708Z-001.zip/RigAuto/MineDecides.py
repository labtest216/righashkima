#!/usr/bin/python
import urllib
import urllib.request
import urllib.parse
import json
from urllib.request import Request, urlopen
jsonurl = urlopen(url)
text = json.loads(jsonurl.read())
print(text)
#req = Request('https://whattomine.com/coins.json', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen('https://whattomine.com/coins.json') as url:
    data = json.loads(url.read().decode())
    print(data)
#webpage = urlopen(req).read()
#json_file = open(webpage, "r+")
#data = json.load(json_file)
#print(str(webpage["Ethereum"]))
# data = json.load(webpage)
# print(json.dump(data, webpage, sort_keys=True, indent=4))
# print(datasort_keys=True, indent=4)

# https://whattomine.com/coins.json